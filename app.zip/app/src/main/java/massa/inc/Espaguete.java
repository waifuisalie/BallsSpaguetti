package massa.inc;

public class Espaguete extends Produto{

    public Espaguete (double quantity, double kilogram_price) {
        super(quantity, kilogram_price);
    }
}
