package massa.inc;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClientReader {
    public static List<Cliente> readClientsFromCSV(String csvFilePath) {
        List<Cliente> clients = new ArrayList<>();

        try (CSVReader reader = new CSVReader(new FileReader(csvFilePath))) {
            String[] header = reader.readNext(); // Read the header row (optional)

            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                String nomeCliente = nextLine[0];
                String CNPJCliente = nextLine[1];
                String EnderecoCliente = nextLine[2];
                String tipoCliente = nextLine[3];

                // Create a Client instance based on the "Tipo de Cliente" value
                Cliente client;
                if ("Supermercado".equalsIgnoreCase(tipoCliente)) {
                    client = new Supermercado(nomeCliente, CNPJCliente, EnderecoCliente);
                } else if ("Restaurante".equalsIgnoreCase(tipoCliente)) {
                    client = new Restaurante(nomeCliente, CNPJCliente, EnderecoCliente);
                } else {
                    // Handle unknown client types or errors as needed
                    System.out.println("Unknown client type: " + tipoCliente);
                    continue; // Skip this client and continue with the next one
                }

                // Add the client to the list
                clients.add(client);
            }
        } catch (IOException | CsvValidationException e) {
            e.printStackTrace(); // Handle or log the exception as needed
        }

        return clients;
    }
}