package massa.inc;

public class Talharim extends Product{

    public Talharim (String pastaType) {
        super(pastaType);
    }
}