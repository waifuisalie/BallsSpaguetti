package massa.inc;

public class Talharim extends Produto{

    public Talharim (double quantity, double kilogram_price) {
        super(quantity, kilogram_price);
    }
}