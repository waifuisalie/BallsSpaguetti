package massa.inc;

public class Spaguetti extends Product{

    public Spaguetti (String pastaType) {
        super(pastaType);
    }
}
