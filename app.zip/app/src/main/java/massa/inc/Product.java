package massa.inc;

public class Product {
    private String pastaType;


    public Product (String pastaType) {
        this.pastaType = pastaType;
    }

    public String getPastaType() {
        return pastaType;
    }
}
