package massa.inc;

public class Canelone extends Product{

    public Canelone (String pastaType) {
        super(pastaType);
    }
}
