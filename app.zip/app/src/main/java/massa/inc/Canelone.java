package massa.inc;

public class Canelone extends Produto{

    public Canelone (double quantity, double kilogram_price) {
        super(quantity, kilogram_price);
    }
}
